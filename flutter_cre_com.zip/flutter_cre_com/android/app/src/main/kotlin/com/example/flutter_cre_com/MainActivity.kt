package com.example.flutter_cre_com

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
