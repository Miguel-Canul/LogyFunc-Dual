/*
  Autor: Miguel Antonio Canul Gerardo
  Descripción: Gestiona y visualiza reportes de actividades.
  Este archivo define la configuración principal de la app, incluyendo servicios de autenticación,
  navegación, manejo del estado con Provider y la interfaz para mostrar un listado filtrable de actividades.
*/

import 'package:flutter/material.dart';
import 'package:flutter_cre_com/reporte_actividades.dart';
import 'package:flutter_cre_com/service.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'auth_service.dart';
import 'auth_provider.dart';
import 'login_screen.dart';
import 'http_client.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Inicialización de SharedPreferences y almacenamiento seguro
  final prefs = await SharedPreferences.getInstance();
  final storage = const FlutterSecureStorage();

  // Cliente HTTP personalizado con autenticación
  final innerClient = http.Client();
  final authClient = HttpClientWithAuth(innerClient, storage);

  // Servicios de autenticación y API
  final authService = AuthService(client: authClient);
  final apiService = ApiService(client: authClient, prefs: prefs);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthProvider>(
          create:
              (_) => AuthProvider(
                authService: authService,
                apiService: apiService,
              ),
        ),
        Provider<AuthService>(create: (_) => authService),
        Provider<ApiService>(create: (_) => apiService),
      ],
      child: MyApp(),
    ),
  );
}

// Clase principal de la app
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mi App',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      onUnknownRoute:
          (settings) =>
              MaterialPageRoute(builder: (context) => const LoginScreen()),
      routes: {
        '/':
            (context) => FutureBuilder(
              future:
                  Provider.of<AuthProvider>(context, listen: false).checkAuth(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  );
                } else if (snapshot.data == true) {
                  return const ReporteActividadesScreen();
                } else {
                  return const LoginScreen();
                }
              },
            ),
        '/login': (context) => const LoginScreen(),
        '/reporte-actividades': (context) => const ReporteActividadesScreen(),
      },
    );
  }
}

// Pantalla que muestra la lista de actividades
class ReporteActividadesScreen extends StatefulWidget {
  const ReporteActividadesScreen({super.key});

  @override
  State<ReporteActividadesScreen> createState() =>
      _ReporteActividadesScreenState();
}

class _ReporteActividadesScreenState extends State<ReporteActividadesScreen> {
  final TextEditingController _searchController = TextEditingController();
  final ApiService _apiService = ApiService();

  List<dynamic> _actividades = [];
  List<dynamic> _filteredActividades = [];
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _cargarActividades();
  }

  // Cargar lista de actividades desde la API
  Future<void> _cargarActividades() async {
    try {
      final actividades = await _apiService.getActividades();
      setState(() {
        _actividades = actividades;
        _filteredActividades = List.from(actividades);
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reporte de Actividades'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _cargarActividades,
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _showConfigDialog,
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage.isNotEmpty
              ? Center(child: Text(_errorMessage))
              : Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _buildSearchBar(),
                    const SizedBox(height: 16),
                    Expanded(child: _buildActivitiesTable()),
                  ],
                ),
              ),
    );
  }

  // Barra de búsqueda y filtros
  Widget _buildSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                hintText: 'Buscar actividad...',
                border: InputBorder.none,
                contentPadding: EdgeInsets.symmetric(vertical: 12),
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (query) {
                setState(() {
                  _filteredActividades = _filterActividades(
                    _actividades,
                    query,
                  );
                });
              },
            ),
          ),
          const SizedBox(width: 8),
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            itemBuilder:
                (context) => const [
                  PopupMenuItem(
                    value: 'recientes',
                    child: Text('Más recientes primero'),
                  ),
                  PopupMenuItem(
                    value: 'antiguos',
                    child: Text('Más antiguos primero'),
                  ),
                  PopupMenuItem(
                    value: 'encargado',
                    child: Text('Ordenar por encargado'),
                  ),
                ],
            onSelected: _applyFilter,
          ),
        ],
      ),
    );
  }

  // Tabla que muestra las actividades filtradas
  Widget _buildActivitiesTable() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        children: [
          Container(
            decoration: BoxDecoration(
              color: const Color(0xFF004b66),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(4),
                topRight: Radius.circular(4),
              ),
            ),
            child: const Row(
              children: [
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'Actividad',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'Encargado',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'Periodo',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child:
                _filteredActividades.isEmpty
                    ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(20),
                        child: Text('No hay actividades disponibles'),
                      ),
                    )
                    : ListView.builder(
                      itemCount: _filteredActividades.length,
                      itemBuilder: (context, index) {
                        final actividad = _filteredActividades[index];
                        return InkWell(
                          onTap:
                              () => _verReporte(
                                actividad['IdActividad'].toString(),
                              ),
                          child: Container(
                            decoration: BoxDecoration(
                              border: Border(
                                bottom: BorderSide(color: Colors.grey[300]!),
                              ),
                              color:
                                  index % 2 == 0
                                      ? Colors.grey[100]
                                      : Colors.white,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Text(
                                      actividad['NombreActividad']
                                              ?.toString() ??
                                          'Sin nombre',
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Text(
                                      actividad['Encargado']?.toString() ??
                                          'No especificado',
                                    ),
                                  ),
                                ),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(12),
                                    child: Text(
                                      actividad['Periodo']?.toString() ??
                                          'No especificado',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
          ),
        ],
      ),
    );
  }

  // Funciones puras Filtra actividades por texto ingresado
  /*void _filterActividades(String query) {
    setState(() {
      _filteredActividades =
          _actividades.where((actividad) {
            final nombre =
                actividad['NombreActividad']?.toString().toLowerCase() ?? '';
            final encargado =
                actividad['Encargado']?.toString().toLowerCase() ?? '';
            final periodo =
                actividad['Periodo']?.toString().toLowerCase() ?? '';
            final searchLower = query.toLowerCase();
            return nombre.contains(searchLower) ||
                encargado.contains(searchLower) ||
                periodo.contains(searchLower);
          }).toList();
    });
  }*/
  List<dynamic> _filterActividades(List<dynamic> actividades, String query) {
    final searchLower = query.toLowerCase();

    return actividades.where((actividad) {
      final campos = [
        actividad['NombreActividad']?.toString().toLowerCase() ?? '',
        actividad['Encargado']?.toString().toLowerCase() ?? '',
        actividad['Periodo']?.toString().toLowerCase() ?? '',
      ];

      return campos.any((campo) => campo.contains(searchLower));
    }).toList();
  }

  // Aplica filtros visuales (aún no implementa la lógica de orden)
  void _applyFilter(String filter) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Filtro aplicado: $filter')));
  }

  // Muestra pantalla de detalles de la actividad
  void _verReporte(String idActividad) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    Navigator.pop(context); // Quita el loader

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ActividadDetailScreen(actividadId: idActividad),
      ),
    );
  }

  // Muestra el diálogo de configuración (cerrar sesión, etc.)
  void _showConfigDialog() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Configuración'),
            content: const Text('Opciones de configuración del reporte'),
            actions: [
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  final authProvider = Provider.of<AuthProvider>(
                    context,
                    listen: false,
                  );
                  await authProvider.logout();
                  Navigator.pushReplacementNamed(context, '/login');
                },
                child: const Text(
                  'Cerrar Sesión',
                  style: TextStyle(color: Colors.red),
                ),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Cerrar'),
              ),
            ],
          ),
    );
  }
}
