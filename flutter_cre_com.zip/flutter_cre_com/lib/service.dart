// Autor: Miguel Antonio Canul Gerardo
// Esta clase encapsula las funcionalidades necesarias para interactuar
// con la API REST de un sistema de gestión de constancias y actividades.
// Incluye autenticación con JWT, gestión de almacenamiento local (shared_preferences),
// generación de constancias con texto personalizado y operaciones CRUD.

import 'package:dartz/dartz.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'modulo_fun_service.dart';

class ApiService {
  /// Devuelve la URL base dependiendo si la app está corriendo en Web o en un emulador.
  static String get baseUrl {
    if (kIsWeb) {
      return 'http://localhost:7288';
    } else {
      return 'http://10.0.2.2:7288';
    }
  }

  final http.Client client;
  final SharedPreferences? prefs;

  int ultimoNumeroConstancia = 35;
  static const String storageKey = 'ultimoNumeroConstancia';

  /// Constructor que inicializa el cliente HTTP y carga el último número de constancia.
  ApiService({http.Client? client, this.prefs})
    : client = client ?? http.Client() {
    _cargarUltimoNumeroConstancia();
  }

  /// Recupera el token JWT desde el almacenamiento seguro.
  Future<String?> _getToken() async {
    try {
      final storage = FlutterSecureStorage();
      final token = await storage.read(key: 'jwt_token');
      return token;
    } catch (e) {
      return null;
    }
  }

  /// Genera los encabezados con el token de autenticación si está disponible.
  Future<Map<String, String>> get _authHeaders async {
    final token = await _getToken();
    final headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
    return headers;
  }

  /// Obtiene todas las constancias detalladas desde la API de AWS.
  Future<List<dynamic>> getTodasConstanciasDetalladas() async {
    try {
      final url =
          'https://ga3alfdamg.execute-api.us-east-1.amazonaws.com/ObtenerConstanciaDetalles';
      final headers = await _authHeaders;

      final response = await client.get(Uri.parse(url), headers: headers);

      if (response.statusCode == 401) {
        throw Exception('Unauthorized: Token inválido o expirado');
      }

      if (response.statusCode == 403) {
        throw Exception(
          'Forbidden: No tienes permisos para acceder a este recurso',
        );
      }

      return _handleResponse(response);
    } catch (e) {
      // Usamos rethrow para preservar el stack trace original
      rethrow;
    }
  }

  /// Método de depuración .
  Future<void> debugTokenStatus() async {
    // Este método es solo para debug
  }

  /// Llama a la API de AWS para generar una constancia con texto personalizado.
  Future<dynamic> generarConstanciaConTexto({
    required String idInscripcion,
    required String idPersonal,
    required String noOficio,
    required String dia,
    required String mes,
    required String anio,
  }) async {
    try {
      // Construye la URL con los parámetros de consulta
      final uri = Uri.parse(
        'https://uk5obruzei.execute-api.us-east-1.amazonaws.com/CrearConstancia',
      ).replace(
        queryParameters: {
          'idInscripcion': idInscripcion,
          'idPersonal': idPersonal,
          'noOficio': noOficio, // Codifica caracteres especiales
          'dia': dia,
          'mes': mes,
          'anio': anio, // Codifica espacios y caracteres especiales
        },
      );

      final headers = await _authHeaders;
      final response = await client.post(uri, headers: headers);

      // Manejo de códigos de estado comunes
      if (response.statusCode == 400) {
        throw Exception('Solicitud incorrecta: verifica los parámetros');
      }
      if (response.statusCode == 401) {
        throw Exception('No autorizado: token inválido o expirado');
      }
      if (response.statusCode == 500) {
        throw Exception('Error interno del servidor');
      }

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error al generar constancia: ${e.toString()}');
    }
  }

  /// Carga el último número de constancia guardado.
  /*
  Future<void> _cargarUltimoNumeroConstancia() async {
    try {
      if (kIsWeb) {
        final storage = await SharedPreferences.getInstance();
        final guardado = storage.getInt(storageKey);

        if (guardado != null && guardado > 0) {
          ultimoNumeroConstancia = guardado;
        } else {
          ultimoNumeroConstancia = 35;
          await _guardarUltimoNumeroConstancia();
        }
      } else {
        if (prefs != null) {
          final guardado = prefs!.getInt(storageKey);
          if (guardado != null && guardado > 0) {
            ultimoNumeroConstancia = guardado;
          } else {
            ultimoNumeroConstancia = 35;
            await _guardarUltimoNumeroConstancia();
          }
        }
      }
    } catch (e) {
      ultimoNumeroConstancia = 35;
    }
  }
  */
  //monada Option
  //"Future<Option<T>> es una mónada compuesta que combina los efectos secundarios de asincronía (Future) y falta de valor (Option)
  //Combina Future y Option para manejar asincronía y valores opcionales.
  //Envuelve valores (some/none), permite composición (then), y maneja efectos (errores) de forma controlada.
  //Elimina los null y centraliza el manejo de errores.
  Future<Option<int>> _cargarUltimoNumeroConstancia() async {
    try {
      // 1. Obtener la instancia de almacenamiento correcta (Web o Mobile)
      final dynamic storage =
          kIsWeb ? await SharedPreferences.getInstance() : prefs;

      // 2. Leer el valor (puede ser null o int)
      final int? guardado = storage?.getInt(storageKey);

      // 3. Convertir a Option y filtrar valores no válidos (<= 0)
      return guardado != null && guardado > 0
          ? some(guardado) // Some(35) si es válido
          : none(); // None() si es null o <= 0
    } catch (e) {
      debugPrint('Error al cargar número: $e');
      return none(); // Fallback seguro
    }
  }

  /// Guarda el último número de constancia en almacenamiento local.
  Future<void> _guardarUltimoNumeroConstancia() async {
    try {
      final dynamic storage =
          kIsWeb ? await SharedPreferences.getInstance() : prefs;
      await storage?.setInt(storageKey, ultimoNumeroConstancia);
    } catch (e) {
      debugPrint('Error al guardar número: $e');
    }
  }

  /* 
  /// Genera un número de oficio único con prefijo personalizado.
  String generarNumeroOficio(String inicial) {
    final anio = DateTime.now().year;
    ultimoNumeroConstancia++;
    _guardarUltimoNumeroConstancia();
    return 'DA-COE-PIT-$inicial-$ultimoNumeroConstancia/$anio';
  }

  /// Devuelve la fecha actual en texto (ej. "veinticuatro de abril de dos mil veinticuatro").
  Map<String, String> obtenerFechaEnTexto() {
    final fecha = DateTime.now();
    final diasNumeros = [
      'uno',
      'dos',
      'tres',
      'cuatro',
      'cinco',
      'seis',
      'siete',
      'ocho',
      'nueve',
      'diez',
      'once',
      'doce',
      'trece',
      'catorce',
      'quince',
      'dieciséis',
      'diecisiete',
      'dieciocho',
      'diecinueve',
      'veinte',
      'veintiuno',
      'veintidós',
      'veintitrés',
      'veinticuatro',
      'veinticinco',
      'veintiséis',
      'veintisiete',
      'veintiocho',
      'veintinueve',
      'treinta',
      'treinta y uno',
    ];
    final meses = [
      'enero',
      'febrero',
      'marzo',
      'abril',
      'mayo',
      'junio',
      'julio',
      'agosto',
      'septiembre',
      'octubre',
      'noviembre',
      'diciembre',
    ];

    final diaNumero = fecha.day;
    final diaTexto =
        (diaNumero - 1 < diasNumeros.length)
            ? diasNumeros[diaNumero - 1]
            : diaNumero.toString();
    final mesTexto = meses[fecha.month - 1];
    final anioTexto = _numeroATexto(fecha.year);

    return {'dia': diaTexto, 'mes': mesTexto, 'anio': anioTexto};
  }

  /// Convierte el año en texto (limitado a 2024 y 2025).
  String _numeroATexto(int numero) {
    if (numero == 2025) return 'dos mil veinticinco';
    if (numero == 2024) return 'dos mil veinticuatro';
    return numero.toString();
  }
*/
  //Funcional

  /// Genera número de oficio usando el módulo puro + estado externo.
  String generarNumeroOficio(String inicial) {
    final anio = DateTime.now().year;
    ultimoNumeroConstancia++;
    _guardarUltimoNumeroConstancia(); // Side effect aislado.
    return ConstanciasUtils.generarNumeroOficio(
      inicial: inicial,
      ultimoNumero: ultimoNumeroConstancia - 1, // Ajuste por el incremento.
      anio: anio,
    );
  }

  /// Obtiene la fecha en texto (delega al módulo puro).
  Map<String, String> obtenerFechaEnTexto() {
    return ConstanciasUtils.obtenerFechaEnTexto(DateTime.now());
  }

  Future<Map<String, dynamic>> obtenerConstancia(String noOficio) async {
    try {
      final uri = Uri.parse(
        'https://ga3alfdamg.execute-api.us-east-1.amazonaws.com/ObtenerConstanciaDetalles?NoOficio=$noOficio',
      );

      final headers = await _authHeaders;
      final response = await client.get(uri, headers: headers);

      if (response.statusCode != 200) {
        throw Exception('Error HTTP ${response.statusCode}: ${response.body}');
      }

      final decodedResponse = jsonDecode(response.body);

      // Verificación del formato (List con un elemento)
      if (decodedResponse is List && decodedResponse.isNotEmpty) {
        return decodedResponse.first
            as Map<String, dynamic>; // Extrae el primer elemento
      } else {
        throw Exception('Formato de respuesta inesperado');
      }
    } catch (e) {
      debugPrint('Error en obtenerConstancia: $e');
      throw Exception(
        'No se pudo obtener la constancia. Verifica el número de oficio',
      );
    }
  }

  /// Elimina una constancia por su número de oficio usando la API de AWS
  Future<Map<String, dynamic>> eliminarConstancia(String noOficio) async {
    try {
      // 1. Construcción de la URL con parámetro (nota el nombre exacto 'NoOficio' con mayúsculas)
      final uri = Uri.parse(
        'https://g6k2am7gil.execute-api.us-east-1.amazonaws.com/EliminarConstanciaDetalles',
      ).replace(
        queryParameters: {
          'NoOficio': noOficio, // AWS usa 'NoOficio' (case-sensitive)
        },
      );

      // 2. Headers de autenticación
      final headers = await _authHeaders;

      // 3. Enviar petición DELETE
      final response = await client.delete(uri, headers: headers);

      // 4. Manejo de respuestas
      switch (response.statusCode) {
        case 200: // Eliminación exitosa (con cuerpo de respuesta)
          return {
            'success': true,
            'message': 'Constancia eliminada exitosamente',
            'data': jsonDecode(response.body),
          };

        case 204: // Eliminación exitosa (sin contenido)
          return {
            'success': true,
            'message': 'Constancia eliminada',
            'data': null,
          };

        case 404:
          throw Exception('No se encontró la constancia con número: $noOficio');

        case 403:
          throw Exception('No tienes permisos para eliminar esta constancia');

        default:
          throw Exception(
            'Error inesperado (${response.statusCode}): ${response.body}',
          );
      }
    } catch (e) {
      debugPrint('Error en eliminarConstancia: $e');
      throw Exception(
        'No se pudo eliminar la constancia: ${e.toString().replaceAll(RegExp(r'^Exception: '), '')}',
      );
    }
  }

  /// Actualiza los datos de una constancia específica en AWS
  Future<Map<String, dynamic>> actualizarConstancia(
    String noOficio,
    Map<String, dynamic> datosConstancia,
  ) async {
    try {
      // 1. Validación de parámetros
      if (noOficio.isEmpty) {
        throw ArgumentError('El número de oficio no puede estar vacío');
      }
      if (datosConstancia.isEmpty) {
        throw ArgumentError(
          'Los datos de actualización no pueden estar vacíos',
        );
      }

      // 2. Construcción de la URL (notar 'NoOficio' con mayúsculas)
      final uri = Uri.parse(
        'https://702rgmduzi.execute-api.us-east-1.amazonaws.com/ActualizarConstanciaDetalles',
      ).replace(
        queryParameters: {
          'noOficio': noOficio, // AWS usa parámetro case-sensitive
        },
      );

      // 3. Configuración de headers
      final headers = {
        ...await _authHeaders,
        'Content-Type': 'application/json', // Requerido para PUT
      };

      // 4. Envío de la petición
      final response = await client.patch(
        uri,
        headers: headers,
        body: jsonEncode(datosConstancia), // Conversión a JSON
      );

      // 5. Manejo de respuestas
      switch (response.statusCode) {
        case 200:
          return {
            'success': true,
            'message': 'Constancia actualizada exitosamente',
            'data': jsonDecode(response.body),
          };

        case 204:
          return {
            'success': true,
            'message': 'Actualización exitosa (sin contenido devuelto)',
            'data': null,
          };

        case 400:
          throw Exception('Datos de actualización inválidos: ${response.body}');

        case 404:
          throw Exception('No se encontró la constancia con número: $noOficio');

        case 403:
          throw Exception('No tienes permisos para actualizar esta constancia');

        default:
          throw Exception(
            'Error inesperado (${response.statusCode}): ${response.body}',
          );
      }
    } on ArgumentError catch (e) {
      throw Exception(e.message);
    } catch (e) {
      debugPrint('Error en actualizarConstancia: ${e.toString()}');
      throw Exception(
        'Error al actualizar constancia: ${e.toString().replaceAll(RegExp(r'^Exception: '), '')}',
      );
    }
  }

  /// Obtiene todas las actividades disponibles desde la API en AWS.
  Future<List<dynamic>> getActividades() async {
    try {
      // final headers = await _authHeaders; // Tus headers de autenticación (si los necesitas)
      final response = await client.get(
        Uri.parse(
          'https://tq3o8nkcqf.execute-api.us-east-1.amazonaws.com/TodasActividadesComplementarias',
        ),
        //  headers: headers,
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error al obtener actividades: $e');
    }
  }

  /// Obtiene los datos de una actividad específica por su ID usando parámetro de consulta.
  Future<Map<String, dynamic>> getActividadById(String id) async {
    try {
      final headers = await _authHeaders;
      final response = await client.get(
        Uri.parse(
          'https://tq3o8nkcqf.execute-api.us-east-1.amazonaws.com/TodasActividadesComplementarias?id=$id',
        ),
        headers: headers,
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error al obtener la actividad: $e');
    }
  }

  /// Obtiene todas las inscripciones completas de alumnos a actividades desde AWS.
  Future<List<dynamic>> getInscripcionesCompletas() async {
    try {
      final headers = await _authHeaders;
      final response = await client.get(
        Uri.parse(
          'https://k8q4q5iw52.execute-api.us-east-1.amazonaws.com/InscripcionesCompletas',
        ),
        headers: headers,
      );

      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error al obtener inscripciones: $e');
    }
  }

  /// Maneja la respuesta HTTP y lanza excepciones si es necesario.
  dynamic _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return {};
      return json.decode(response.body);
    } else if (response.statusCode == 401) {
      throw Exception('No autorizado - Por favor inicie sesión nuevamente');
    } else {
      throw Exception(
        'Error en la solicitud: ${response.statusCode} ${response.reasonPhrase}',
      );
    }
  }
}
