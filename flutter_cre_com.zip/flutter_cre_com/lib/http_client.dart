// Autor: Miguel Antonio Canul Gerardo
// Descripción: Esta clase extiende el cliente HTTP base de Dart para interceptar y agregar automáticamente
// un token JWT (almacenado de forma segura) a las peticiones salientes. Es útil para manejar autenticación
// en aplicaciones Flutter que consumen APIs seguras.

import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class HttpClientWithAuth extends http.BaseClient {
  final http.Client
  _inner; // Cliente HTTP interno usado para enviar las peticiones reales.
  final FlutterSecureStorage
  _storage; // Almacenamiento seguro para recuperar el token JWT.

  HttpClientWithAuth(this._inner, this._storage);

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) async {
    // Lee el token JWT almacenado de forma segura
    final token = await _storage.read(key: 'jwt_token');

    // Si existe un token, se agrega al encabezado Authorization
    if (token != null) {
      request.headers['Authorization'] = 'Bearer $token';
    }

    // Se especifica que se trabajará con datos en formato JSON
    request.headers['Content-Type'] = 'application/json';
    request.headers['Accept'] = 'application/json';

    // Registro de la URL y encabezados antes de enviar la solicitud (útil para depuración)
    print('Sending to ${request.url} with headers: ${request.headers}');

    // Envía la solicitud usando el cliente interno
    return _inner.send(request);
  }
}
