import 'package:flutter/material.dart';
import 'package:flutter_cre_com/Service.dart';
import 'package:flutter_cre_com/auth_provider.dart';
import 'package:flutter_cre_com/constancia.dart';
import 'package:provider/provider.dart';
/*
  Autor: Miguel Antonio Canul Gerardo
  Descripción: Este widget muestra los detalles
   de una actividad complementaria y permite gestionar las constancias de los alumnos participantes.
*/

class ActividadDetailScreen extends StatefulWidget {
  final String actividadId;

  const ActividadDetailScreen({super.key, required this.actividadId});

  @override
  State<ActividadDetailScreen> createState() => _ActividadDetailScreenState();
}

class _ActividadDetailScreenState extends State<ActividadDetailScreen> {
  late Future<Map<String, dynamic>> _actividadData;
  final ApiService apiService = ApiService();
  bool _isLoading = true;
  String _errorMessage = '';
  List<dynamic> _constanciasDetalladas = [];

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
        _actividadData = _fetchActividadData();
      });

      await Future.wait([_actividadData, _cargarConstanciasDetalladas()]);
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }
  /*
  Future<Map<String, dynamic>> _fetchActividadData() async {
    try {
      final actividad = await apiService.getActividadById(widget.actividadId);
      final alumnos = List.from(actividad['alumnos'] ?? []);

      // Asignar números de oficio solo si las constancias están cargadas
      if (_constanciasDetalladas.isNotEmpty) {
        _asignarNoOficioAAlumnos(alumnos, actividad);
      }

      return {'actividad': actividad, 'alumnos': alumnos};
    } catch (e) {
      debugPrint('Error al cargar actividad: $e');
      rethrow;
    }
  }
*/

  Future<Map<String, dynamic>> _fetchActividadData() async {
    try {
      final actividad = await apiService.getActividadById(widget.actividadId);

      // Conversión segura a List<Map<String, dynamic>>
      final List<dynamic> alumnosDynamic = actividad['alumnos'] ?? [];
      final List<Map<String, dynamic>> alumnos =
          alumnosDynamic
              .where((alumno) => alumno is Map<String, dynamic>)
              .cast<Map<String, dynamic>>()
              .toList();

      // Versión funcional con tipado explícito
      final List<Map<String, dynamic>> alumnosActualizados =
          _constanciasDetalladas.isNotEmpty
              ? _asignarNoOficioAAlumnos(alumnos, actividad)
              : alumnos;

      return {'actividad': actividad, 'alumnos': alumnosActualizados};
    } catch (e) {
      debugPrint('Error al cargar actividad: $e');
      rethrow;
    }
  }

  Future<void> _cargarConstanciasDetalladas() async {
    try {
      // Espera a que _actividadData esté listo
      final actividadData = await _actividadData;

      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final isLoggedIn = await authProvider.checkAuth();

      if (!isLoggedIn) throw Exception('Sesión no válida');

      final constancias = await apiService.getTodasConstanciasDetalladas();

      if (mounted) {
        setState(() {
          _constanciasDetalladas = constancias;
          // Actualiza los números de oficio
          _asignarNoOficioAAlumnos(
            actividadData['alumnos'],
            actividadData['actividad'],
          );
        });
      }
    } catch (e) {
      debugPrint('Error al cargar constancias: $e');
      if (mounted) {
        setState(() {
          _errorMessage = e.toString();
        });
      }
      rethrow;
    }
  }

  /*
  // Asigna el noOficio a cada alumno si existe una constancia para él
  List<dynamic> _asignarNoOficioAAlumnos(
    List<dynamic> alumnos,
    Map<String, dynamic> actividad,
  ) {
    if (alumnos.isEmpty || _constanciasDetalladas.isEmpty) return alumnos;

    for (var alumno in alumnos) {
      final constancia = _constanciasDetalladas.firstWhere(
        (c) =>
            c['NumeroControl'] == alumno['numeroControl'] &&
            c['ActividadComplementaria'] == actividad['NombreActividad'],
        orElse: () => {},
      );

      if (constancia.isNotEmpty) {
        alumno['noOficio'] = constancia['NoOficio'];
        alumno['tieneConstancia'] = true;
      } else {
        alumno['noOficio'] = null;
        alumno['tieneConstancia'] = false;
      }
    }

    return alumnos;
  }
*/
  List<Map<String, dynamic>> _asignarNoOficioAAlumnos(
    List<Map<String, dynamic>> alumnos,
    Map<String, dynamic> actividad,
  ) {
    return alumnos.isEmpty || _constanciasDetalladas.isEmpty
        ? alumnos
        : alumnos.map(_transformarAlumno(actividad)).toList();
  }

  Map<String, dynamic> Function(Map<String, dynamic>) _transformarAlumno(
    Map<String, dynamic> actividad,
  ) {
    return (alumno) {
      final constancia = _constanciasDetalladas.firstWhere(
        (c) =>
            c['NumeroControl'] == alumno['numeroControl'] &&
            c['ActividadComplementaria'] == actividad['NombreActividad'],
        orElse: () => {},
      );

      return {
        ...alumno,
        'noOficio': constancia['NoOficio'],
        'tieneConstancia': constancia.isNotEmpty,
      };
    };
  }

  Future<void> _generarConstancia(Map<String, dynamic> alumno) async {
    // 1. Verificar montado primero
    if (!mounted) return;

    // 2. Obtener provider al inicio del método
    Provider.of<AuthProvider>(context, listen: false);
    try {
      // 1. Preparación de datos iniciales
      final actividad = (await _actividadData)['actividad'];
      final idActividad = actividad['IdActividad'];
      const idPersonal = '4';
      final inicial = actividad['Inicial'] ?? 'X';

      // 2. Verificar montaje del widget al inicio
      if (!mounted) return;

      // 3. Obtener AuthProvider de manera segura
      Provider.of<AuthProvider>(context, listen: false);

      // 4. Obtener inscripciones con manejo de error específico
      final inscripciones = await apiService
          .getInscripcionesCompletas()
          .catchError((e) {
            debugPrint('Error al obtener inscripciones: $e');
            throw Exception('No se pudieron obtener las inscripciones');
          });

      final inscripcion = inscripciones.firstWhere(
        (ins) =>
            ins['idActividadComp'] == idActividad &&
            ins['numeroControlAlumno'] == alumno['numeroControl'],
        orElse: () => {},
      );

      if (inscripcion.isEmpty) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Inscripción no encontrada para este alumno'),
          ),
        );
        return;
      }

      // 5. Preparación datos para constancia
      final idInscripcion = inscripcion['inscripcionId'].toString();
      final noOficio = apiService.generarNumeroOficio(inicial);
      final fechaTexto = apiService.obtenerFechaEnTexto();

      debugPrint('Datos para constancia:');
      debugPrint('- ID Inscripción: $idInscripcion');
      debugPrint('- N° Oficio: $noOficio');
      debugPrint(
        '- Fecha: ${fechaTexto['dia']}/${fechaTexto['mes']}/${fechaTexto['anio']}',
      );

      // 6. Diálogo de confirmación
      final confirm = await showDialog<bool>(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text('Confirmar Generación'),
              content: Text(
                '¿Generar constancia para ${alumno['nombreCompleto']}?\n'
                'N° de Oficio: $noOficio',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Cancelar'),
                ),
                TextButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('Confirmar'),
                ),
              ],
            ),
      );

      if (confirm != true || !mounted) return;

      // 7. Mostrar carga
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(child: CircularProgressIndicator()),
      );

      // 8. Generación de constancia
      await apiService.generarConstanciaConTexto(
        idInscripcion: idInscripcion,
        idPersonal: idPersonal,
        noOficio: noOficio,
        dia: fechaTexto['dia']!,
        mes: fechaTexto['mes']!,
        anio: fechaTexto['anio']!,
      );

      // 9. Actualización de datos
      await _cargarConstanciasDetalladas();

      if (!mounted) return;
      Navigator.pop(context); // Cerrar diálogo de carga

      // 10. Mostrar resultado

      // 11. Actualizar estado
      setState(() {
        _actividadData = _fetchActividadData().then((data) {
          _asignarNoOficioAAlumnos(data['alumnos'], data['actividad']);
          return data;
        });
      });
    } catch (e) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      debugPrint('Error en _generarConstancia: ${e.toString()}');

      if (mounted) Navigator.pop(context);

      // Ahora authProvider es accesible aquí
      if (e.toString().contains('401')) {
        await authProvider.logout();
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/login');
        }
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle de Actividad'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadInitialData,
          ),
        ],
      ),
      body:
          _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage.isNotEmpty
              ? Center(child: Text(_errorMessage))
              : FutureBuilder<Map<String, dynamic>>(
                future: _actividadData,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (snapshot.hasError) {
                    return Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('Error: ${snapshot.error}'),
                          ElevatedButton(
                            onPressed: _loadInitialData,
                            child: const Text('Reintentar'),
                          ),
                        ],
                      ),
                    );
                  }

                  final data = snapshot.data!;
                  final actividad = data['actividad'];
                  final alumnos = data['alumnos'];

                  return SingleChildScrollView(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        _buildActividadHeader(actividad, alumnos.length),
                        const SizedBox(height: 20),
                        _buildAlumnosTable(alumnos),
                      ],
                    ),
                  );
                },
              ),
    );
  }

  Widget _buildActividadHeader(
    Map<String, dynamic> actividad,
    int alumnosCount,
  ) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Fila superior: Título y categoría
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Text(
                    actividad['NombreActividad'] ?? 'Sin nombre',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    actividad['Categoria'] ?? '',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Fila media: Contenido principal
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Imagen
                CircleAvatar(
                  radius: 40,
                  backgroundImage: AssetImage(
                    'assets/images/${actividad['RutaImg'] ?? 'default_activity.png'}',
                  ),
                ),

                const SizedBox(width: 16),

                // Contenido de texto expandible
                Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Columna izquierda (detalles principales)
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildInfoRow(
                              'Encargado:',
                              actividad['Encargado'] ?? 'No especificado',
                            ),
                            _buildInfoRow(
                              'Aula:',
                              actividad['Aula'] ?? 'No especificado',
                            ),
                            _buildInfoRow(
                              'Estado:',
                              actividad['Estado'] ?? 'No especificado',
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(width: 16),

                      // Columna derecha (detalles secundarios)
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildInfoRow('Alumnos:', alumnosCount.toString()),
                            _buildInfoRow(
                              'Créditos:',
                              actividad['Creditos']?.toString() ?? '0',
                            ),
                            _buildInfoRow(
                              'Fechas:',
                              '${_formatDate(actividad['FechaInicio'])} - ${_formatDate(actividad['FechaFin'])}',
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Funcion pura Widget auxiliar para mostrar filas de información
  //misma entrada y salida : Mismos inputs → Mismo output
  //No modifica nada fuera de la función no altera variables ni hace llamadas a APIs, bases de datos, o print()

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 16, color: Colors.black),
          children: [
            TextSpan(
              text: '$label ',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  Widget _buildAlumnosTable(List<dynamic> alumnos) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            // Encabezado de la tabla
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF004b66),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Row(
                children: [
                  Expanded(
                    flex: 4,
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Alumno',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: Text(
                        'Constancia',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  Expanded(flex: 3, child: SizedBox()),
                ],
              ),
            ),
            // Lista de alumnos
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: alumnos.length,
              itemBuilder: (context, index) {
                final alumno = alumnos[index];
                final tieneConstancia = alumno['noOficio'] != null;
                final nombreCompleto =
                    alumno['nombreCompleto'] ?? 'Nombre no disponible';
                final nombrePartes = nombreCompleto.split(' ');
                final nombreFormateado =
                    nombrePartes.length > 2
                        ? '${nombrePartes[0]} ${nombrePartes[1]}\n${nombrePartes.sublist(2).join(' ')}'
                        : nombreCompleto;

                return Container(
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(color: Colors.grey[300]!),
                    ),
                    color: index % 2 == 0 ? Colors.grey[100] : Colors.white,
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            nombreFormateado,
                            style: const TextStyle(fontSize: 14),
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 3,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Text(
                            alumno['noOficio']?.toString() ?? 'Sin constancia',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                      Expanded(
                        flex: 3,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 0),
                          child: Wrap(
                            spacing: 2, // Espacio reducido entre botones
                            alignment: WrapAlignment.center,
                            children:
                                tieneConstancia
                                    ? [
                                      _buildIconButton(
                                        Icons.visibility,
                                        () => _verConstancia(alumno),
                                      ),
                                      _buildIconButton(
                                        Icons.edit,
                                        () => _editarConstancia(alumno),
                                      ),
                                      _buildIconButton(
                                        Icons.delete,
                                        () => _eliminarConstancia(alumno),
                                      ),
                                    ]
                                    : [
                                      _buildIconButton(
                                        Icons.add,
                                        () => _generarConstancia(alumno),
                                      ),
                                    ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // Widget auxiliar para iconos compactos
  Widget _buildIconButton(IconData icon, VoidCallback onPressed) {
    return IconButton(
      icon: Icon(icon, size: 20),
      iconSize: 20,
      onPressed: onPressed,
      color: Colors.blue,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(),
    );
  }

  //Funcion pura
  //Misma entrada misma salida dateString
  //No depende de estados externos
  //No modifica nada fuera de la funcion
  String _formatDate(String? dateString) {
    if (dateString == null) return 'No especificado';
    try {
      final date = DateTime.parse(dateString);
      return '${date.day}/${date.month}/${date.year}';
    } catch (e) {
      return dateString;
    }
  }

  void _verConstancia(Map<String, dynamic> alumno) {
    if (alumno['noOficio'] == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El alumno no tiene constancia generada')),
      );
      return;
    }

    // Navegar a la pantalla de visualización de constancia
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => PantallaVistaConstancia(
              noOficio: alumno['noOficio'],
              alumno: alumno,
            ),
      ),
    );
  }

  void _editarConstancia(Map<String, dynamic> alumno) {
    if (alumno['noOficio'] == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El alumno no tiene constancia generada')),
      );
      return;
    }

    // Navegar a la pantalla de visualización de constancia en modo edición
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => PantallaVistaConstancia(
              noOficio: alumno['noOficio'],
              alumno: alumno,
              esEditable: true, // ¡Aquí activamos el modo edición!
            ),
      ),
    );
  }

  Future<void> _eliminarConstancia(Map<String, dynamic> alumno) async {
    if (alumno['noOficio'] == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('El alumno no tiene constancia generada')),
      );
      return;
    }

    final confirm = await showDialog<bool>(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text('Eliminar Constancia'),
            content: Text(
              '¿Estás seguro de eliminar la constancia ${alumno['noOficio']} '
              'de ${alumno['nombreCompleto']}?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Cancelar'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text(
                  'Eliminar',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
          ),
    );

    if (confirm == true) {
      try {
        // Mostrar indicador de carga
        showDialog(
          context: context,
          barrierDismissible: false,
          builder:
              (context) => const Center(child: CircularProgressIndicator()),
        );

        // TODO: Implementar eliminación de constancia en el API
        await apiService.eliminarConstancia(alumno['noOficio']);

        // Actualizar la lista de constancias
        await _cargarConstanciasDetalladas();

        // Cerrar el diálogo de carga
        if (mounted) Navigator.pop(context);

        // Mostrar mensaje de éxito

        // Actualizar los datos de la actividad
        setState(() {
          _actividadData = _fetchActividadData();
        });
      } catch (e) {
        debugPrint('Error al eliminar constancia: $e');
        if (mounted) {
          Navigator.pop(context); // Cerrar diálogo de carga si está abierto
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error al eliminar constancia: ${e.toString()}'),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    }
  }
}
