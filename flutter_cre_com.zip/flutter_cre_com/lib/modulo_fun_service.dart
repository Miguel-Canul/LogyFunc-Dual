// lib/utils/modulo_fun_service.dart

/// Módulo funcional con operaciones puras relacionadas a constancias.
/// 1. Transparencia referencial : El resultado siempre es el mismo para los mismos argumentos de entrada, sin depender de estado externo o mutable.
/// No tienen efectos secundarios.
/// No dependen de estado externo mutable.
class ConstanciasUtils {
  /// Genera un número de oficio sin estado externo.
  /// (Ahora recibe el último número como parámetro).
  static String generarNumeroOficio({
    required String inicial,
    required int ultimoNumero,
    required int anio,
  }) {
    return 'DA-COE-PIT-$inicial-${ultimoNumero + 1}/$anio';
  }

  /// Devuelve la fecha en formato texto (ej. "veinticuatro de abril de 2024").
  static Map<String, String> obtenerFechaEnTexto(DateTime fecha) {
    final diasNumeros = [
      'uno',
      'dos',
      'tres',
      'cuatro',
      'cinco',
      'seis',
      'siete',
      'ocho',
      'nueve',
      'diez',
      'once',
      'doce',
      'trece',
      'catorce',
      'quince',
      'dieciséis',
      'diecisiete',
      'dieciocho',
      'diecinueve',
      'veinte',
      'veintiuno',
      'veintidós',
      'veintitrés',
      'veinticuatro',
      'veinticinco',
      'veintiséis',
      'veintisiete',
      'veintiocho',
      'veintinueve',
      'treinta',
      'treinta y uno',
    ];
    final meses = [
      'enero',
      'febrero',
      'marzo',
      'abril',
      'mayo',
      'junio',
      'julio',
      'agosto',
      'septiembre',
      'octubre',
      'noviembre',
      'diciembre',
    ];

    return {
      'dia': diasNumeros[fecha.day - 1],
      'mes': meses[fecha.month - 1],
      'anio': _numeroATexto(fecha.year),
    };
  }

  /// Convierte un año a texto (pura y privada).
  static String _numeroATexto(int numero) {
    if (numero == 2025) return 'dos mil veinticinco';
    if (numero == 2024) return 'dos mil veinticuatro';
    return numero.toString();
  }
}
