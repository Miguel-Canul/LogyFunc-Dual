/// Clase que representa la solicitud de inicio de sesión
/// Autor: Miguel Antonio Canul Gerardo
/// Contiene:
/// - Credenciales del usuario (email y contraseña)
/// - Bandera para recordar sesión
class LoginRequest {
  final String email;
  final String password;
  final bool rememberMe;

  LoginRequest({
    required this.email,
    required this.password,
    this.rememberMe = false,
  });

  /// Serializa el objeto a formato JSON para enviar al servidor
  Map<String, dynamic> toJson() => {
    'email': email,
    'password': password,
    'rememberMe': rememberMe,
  };
}

/// Clase que representa la respuesta del servidor al iniciar sesión
/// Autor: Miguel Antonio Canul Gerardo
/// Contiene:
/// - Email del usuario autenticado
/// - Tiempo de expiración de la sesión (en segundos)
class LoginResponse {
  final String email;
  final int expiresIn;

  LoginResponse({required this.email, required this.expiresIn});

  /// Constructor que crea una instancia a partir de un JSON
  factory LoginResponse.fromJson(Map<String, dynamic> json) =>
      LoginResponse(email: json['email'], expiresIn: json['expiresIn']);
}
