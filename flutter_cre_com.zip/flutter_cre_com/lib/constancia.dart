// pantalla_vista_constancia.dart
///Pantalla para visualizar y editar constancias académicas
// Autor: Miguel Antonio Canul Gerardo
import 'package:flutter/material.dart';
import 'package:flutter_cre_com/service.dart';
import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_html/flutter_html.dart';

// Widget de pantalla para visualizar/editar constancias académicas
class PantallaVistaConstancia extends StatefulWidget {
  // Parámetros recibidos:
  // - noOficio: número de oficio de la constancia
  // - alumno: datos opcionales del alumno
  // - esEditable: bandera para determinar si la pantalla permite edición
  final String noOficio;
  final Map<String, dynamic>? alumno;
  final bool esEditable;

  const PantallaVistaConstancia({
    super.key,
    required this.noOficio,
    this.alumno,
    this.esEditable = false,
  });

  @override
  State<PantallaVistaConstancia> createState() =>
      _EstadoPantallaVistaConstancia();
}

// Estado de la pantalla de constancias
class _EstadoPantallaVistaConstancia extends State<PantallaVistaConstancia> {
  late Map<String, dynamic> _constancia; // Almacena los datos de la constancia
  late final ApiService _apiService; // Servicio para llamadas a la API

  // Variables de estado:
  bool _cargando = true; // Indica si se están cargando los datos
  bool _editando = false; // Controla el modo edición
  Uint8List? _logoIzquierdo; // Imagen del logo izquierdo
  Uint8List? _logoDerecho; // Imagen del logo derecho
  Uint8List? _imagenPiePagina; // Imagen del pie de página
  double _fontSize = 10.5; // Tamaño de fuente para el contenido

  @override
  void initState() {
    super.initState();
    _apiService = ApiService(); // Inicializa el servicio API
    _editando = widget.esEditable; // Establece el modo edición inicial
    // Inicializa la estructura de datos de la constancia con valores por defecto
    _constancia = {
      'Fecha': '',
      'noOficio': widget.noOficio,
      'Asunto': '',
      'DEPARTAMENTO_DE_SERVICIOS_ESCOLARES': '',
      'Nombre': '',
      'NumeroControl': '',
      'Carrera': '',
      'ActividadComplementaria': '',
      'Desempenio': '',
      'Valornumerico': 0,
      'Creditos': 0,
      'PeriodoEscolar': '',
      'COORDINACION_DE_ORIENTACION_EDUCATIVA': '',
      'JEFA_DEL_DEPTO_DE_DESARROLLO_ACADEMICO': '',
      'Dia': '',
      'Mes': '',
      'Anio': '',
      'Categoria': '',
    };
    _cargarDatosConstancia(); // Carga los datos de la constancia desde la API
    _cargarImagenes(); // Carga las imágenes locales
  }

  // Carga imágenes desde los assets
  Future<void> _cargarImagenes() async {
    try {
      _logoIzquierdo = await _cargarImagen('assets/images/Logo-izq.png');
      _logoDerecho = await _cargarImagen('assets/images/logo-der.png');
      _imagenPiePagina = await _cargarImagen('assets/images/footer2025.png');
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('Error al cargar imágenes: $e');
    }
  }

  // Helper para cargar una imagen como Uint8List
  Future<Uint8List> _cargarImagen(String ruta) async {
    final data = await rootBundle.load(ruta);
    return data.buffer.asUint8List();
  }

  // Obtiene los datos de la constancia desde el backend
  Future<void> _cargarDatosConstancia() async {
    try {
      final datos = await _apiService.obtenerConstancia(widget.noOficio);
      setState(() {
        // Actualiza el estado con los datos recibidos
        _constancia = {
          ..._constancia,
          'Fecha': datos['Fecha']?.split('T')[0] ?? '',
          'Dia': datos['Dia'] ?? '',
          'Nombre': datos['Nombre'] ?? '',
          'NumeroControl': datos['NumeroControl'] ?? '',
          'Carrera': datos['Carrera'] ?? '',
          'Mes': datos['Mes'] ?? '',
          'Anio': datos['Anio'] ?? '',
          'Asunto': datos['Asunto'] ?? '',
          'ActividadComplementaria': datos['ActividadComplementaria'] ?? '',
          'Desempenio': datos['Desempenio'] ?? '',
          'Valornumerico': datos['Valornumerico'] ?? 0,
          'Creditos': datos['Creditos'] ?? 0,
          'PeriodoEscolar': datos['PeriodoEscolar'] ?? '',
          'Categoria': datos['Categoria'] ?? '',
          'DEPARTAMENTO_DE_SERVICIOS_ESCOLARES':
              datos['DEPARTAMENTO_DE_SERVICIOS_ESCOLARES'] ?? '',
          'COORDINACION_DE_ORIENTACION_EDUCATIVA':
              datos['COORDINACION_DE_ORIENTACION_EDUCATIVA'] ?? '',
          'JEFA_DEL_DEPTO_DE_DESARROLLO_ACADEMICO':
              datos['JEFA_DEL_DEPTO_DE_DESARROLLO_ACADEMICO'] ?? '',
        };
        _cargando = false; // Finaliza el estado de carga
      });
    } catch (e) {
      debugPrint('Error al cargar datos de la constancia: $e');
      setState(() {
        _cargando = false;
      });
    }
  }

  // Alterna entre modo visualización y edición
  void _alternarEdicion() {
    setState(() {
      _editando = !_editando;
    });
  }

  // Guarda los cambios de la constancia en el backend
  Future<void> _guardarConstancia() async {
    try {
      // Muestra un indicador de carga
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(child: CircularProgressIndicator()),
      );

      // Prepara los datos para enviar al backend
      final datosActualizados = {
        'Fecha': _constancia['Fecha'],
        'noOficio': _constancia['noOficio'],
        'Asunto': _constancia['Asunto'],
        'DEPARTAMENTO_DE_SERVICIOS_ESCOLARES':
            _constancia['DEPARTAMENTO_DE_SERVICIOS_ESCOLARES'],
        'Nombre': _constancia['Nombre'],
        'NumeroControl': _constancia['NumeroControl'],
        'Carrera': _constancia['Carrera'],
        'ActividadComplementaria': _constancia['ActividadComplementaria'],
        'Desempenio': _constancia['Desempenio'],
        'Valornumerico': _constancia['Valornumerico'],
        'Creditos': _constancia['Creditos'],
        'PeriodoEscolar': _constancia['PeriodoEscolar'],
        'COORDINACION_DE_ORIENTACION_EDUCATIVA':
            _constancia['COORDINACION_DE_ORIENTACION_EDUCATIVA'],
        'JEFA_DEL_DEPTO_DE_DESARROLLO_ACADEMICO':
            _constancia['JEFA_DEL_DEPTO_DE_DESARROLLO_ACADEMICO'],
        'Dia': _constancia['Dia'],
        'Mes': _constancia['Mes'],
        'Anio': _constancia['Anio'],
        'Categoria': _constancia['Categoria'],
      };

      // Llama al servicio para actualizar la constancia
      final resultado = await _apiService.actualizarConstancia(
        _constancia['noOficio'],
        datosActualizados,
      );

      if (mounted) Navigator.pop(context); // Cierra el diálogo de carga

      // Maneja la respuesta del backend
      if (resultado['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Constancia actualizada exitosamente'),
            duration: Duration(seconds: 2),
          ),
        );

        setState(() {
          _editando = false; // Sale del modo edición
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al actualizar: ${resultado['message']}'),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (mounted) Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error al actualizar: ${e.toString()}'),
          duration: const Duration(seconds: 3),
          action: SnackBarAction(
            label: 'Reintentar',
            onPressed: _guardarConstancia, // Permite reintentar
          ),
        ),
      );
    }
  }

  /// Construye un campo editable o de solo visualización dependiendo del modo [_editando]
  Widget _construirCampoEditable(
    String etiqueta,
    String valor,
    String claveCampo, {
    bool esNumerico = false,
  }) {
    return _editando
        ? Container(
          margin: const EdgeInsets.only(bottom: 2.0),
          child: IntrinsicWidth(
            // Widget que ajusta su ancho al contenido interno
            child: Container(
              constraints: BoxConstraints(
                maxWidth:
                    MediaQuery.of(context).size.width *
                    0.55, // Máximo 55% del ancho de pantalla
                minWidth: 70, // Ancho mínimo para que sea usable
              ),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey), // Borde gris
                borderRadius: BorderRadius.circular(3), // Esquinas redondeadas
              ),
              child: TextFormField(
                initialValue: valor,
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 4,
                    vertical: 2,
                  ),
                  border: InputBorder.none, // Sin borde interno
                  isDense: true, // Reduce el espacio vertical
                ),
                style: TextStyle(fontSize: _fontSize, height: 0.8),
                maxLines: 1, // Solo una línea
                keyboardType:
                    esNumerico ? TextInputType.number : TextInputType.text,
                onChanged: (nuevoValor) {
                  // Actualiza el estado con el nuevo valor
                  setState(() {
                    _constancia[claveCampo] =
                        esNumerico ? int.tryParse(nuevoValor) ?? 0 : nuevoValor;
                  });
                },
              ),
            ),
          ),
        )
        : Padding(
          // Modo de solo visualización (no editable)
          padding: const EdgeInsets.only(bottom: 2.0),
          child: RichText(
            text: TextSpan(
              style: TextStyle(
                fontSize: _fontSize,
                fontWeight: FontWeight.bold, // Texto en negritas
                color: Colors.black,
                height: 1.0,
              ),
              children: [TextSpan(text: valor)],
            ),
          ),
        );
  }

  /// Construye el contenido de la constancia dependiendo del modo [_editando]
  Widget _buildContenidoConstancia() {
    if (_editando) {
      // Modo edición: muestra campos editables
      return _buildContenidoEditable();
    } else {
      // Modo visualización: genera el HTML formateado
      final contenido = _generarTextoConstancia();
      return Html(
        data: contenido,
        style: {
          "body": Style(
            margin: Margins.zero,
            padding: HtmlPaddings.zero,
            fontSize: FontSize(_fontSize),
            lineHeight: LineHeight(1.1),
            textAlign: TextAlign.justify,
          ),
          "b": Style(fontWeight: FontWeight.bold), // Estilo para etiquetas <b>
        },
      );
    }
  }

  /// Construye el contenido editable de la constancia con campos interactivos
  Widget _buildContenidoEditable() {
    // Segmentos de texto que forman la constancia (alternan texto fijo y campos editables)
    final textSegments = [
      'La que suscribe, por este medio hace constar que el (la) estudiante ',
      _constancia['Nombre'] ?? 'Patricia Vargas Flores',
      ' con número de control ',
      _constancia['NumeroControl'] ?? '20230006',
      ' de la carrera de ',
      _constancia['Carrera'] ?? 'Medicina',
      ', ha CUMPLIDO la actividad complementaria: ',
      _constancia['ActividadComplementaria'] ?? 'Ajedrez',
      ', con el nivel de desempeño ',
      _constancia['Desempenio'] ?? 'Bueno',
      ', valor numérico de ',
      _constancia['Valornumerico']?.toString() ?? '3',
      ', valor curricular de ',
      _constancia['Creditos']?.toString() ?? '0.5',
      ' crédito(s), durante el período escolar: ',
      _constancia['PeriodoEscolar'] ?? '2025-A',
      '.',
    ];

    final spans = <InlineSpan>[]; // Almacena los segmentos de texto/Widgets

    for (var i = 0; i < textSegments.length; i++) {
      final segment = textSegments[i];

      if (i % 2 == 1) {
        // Procesa campos editables (segmentos impares)
        final key =
            [
              'Nombre',
              'NumeroControl',
              'Carrera',
              'ActividadComplementaria',
              'Desempenio',
              'Valornumerico',
              'Creditos',
              'PeriodoEscolar',
            ][(i - 1) ~/ 2]; // Obtiene la clave correspondiente

        // Campos que no deben ser editables (solo visualización)
        final bool noEditable = [
          'Nombre',
          'NumeroControl',
          'Carrera',
          'ActividadComplementaria',
          'PeriodoEscolar',
        ].contains(key);

        spans.add(
          noEditable
              ? TextSpan(
                // Texto no editable (negritas)
                text: segment,
                style: TextStyle(
                  fontSize: _fontSize,
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              )
              : WidgetSpan(
                // Campo editable
                alignment: PlaceholderAlignment.middle,
                child: _construirCampoEditable(
                  segment,
                  segment,
                  key,
                  esNumerico: key == 'valornumerico' || key == 'creditos',
                ),
              ),
        );
      } else {
        // Texto estático normal
        spans.add(
          TextSpan(
            text: segment,
            style: TextStyle(fontSize: _fontSize, color: Colors.black),
          ),
        );
      }
    }

    return RichText(
      textAlign: TextAlign.justify,
      text: TextSpan(
        style: TextStyle(fontSize: _fontSize, height: 1.1, color: Colors.black),
        children: spans,
      ),
    );
  }

  /*
  /// Genera el texto HTML de la constancia con formato para visualización
  String _generarTextoConstancia() {
    // Segmentos que componen el texto de la constancia
    final segments = [
      {
        'prefix':
            'La que suscribe, por este medio hace constar que el (la) estudiante ',
        'key': 'Nombre',
        'editable': _editando,
      },
      {
        'prefix': ' con número de control ',
        'key': 'NumeroControl',
        'editable': _editando,
      },
      {'prefix': ' de la carrera de ', 'key': 'Carrera', 'editable': _editando},
      {
        'prefix': ', ha CUMPLIDO la actividad complementaria: ',
        'key': 'ActividadComplementaria',
        'editable': _editando,
      },
      {
        'prefix': ', con el nivel de desempeño ',
        'key': 'Desempenio',
        'editable': _editando,
      },
      {
        'prefix': ', valor numérico de ',
        'key': 'Valornumerico',
        'editable': _editando,
      },
      {
        'prefix': ', valor curricular de ',
        'key': 'Creditos',
        'editable': _editando,
      },
      {
        'prefix': ' crédito(s), durante el período escolar: ',
        'key': 'PeriodoEscolar',
        'editable': _editando,
      },
      {'prefix': '.', 'key': null}, // Segmento final sin campo editable
    ];

    final buffer = StringBuffer(); // Para construir el string eficientemente

    for (final segment in segments) {
      buffer.write(segment['prefix']); // Escribe el texto fijo

      final key = segment['key'];
      if (key != null && segment['editable'] == false) {
        // Solo procesa valores en modo no-editable
        final value = _constancia[key];
        if (value != null) {
          buffer.write('<b>${value.toString()}</b>'); // Valores en negritas
        } else {
          buffer.write(
            '<b>[Valor no especificado]</b>',
          ); // Placeholder para valores faltantes
        }
      }
    }

    return buffer.toString();
  }
  */
  /// Genera el texto HTML de la constancia con formato para visualización
  /// Funcional
  /// 1. Inmutabilidad : no modificar esta estructura después de su creación
  /// 2. Funciones puras: Siempre produce la misma salida para la misma entrada.
  /// 3. Uso de operaciones funcionales (map y fold) similar al fmap y reduce
  String _generarTextoConstancia() {
    // Definición de segmentos como lista de mapas (inmutable)
    final segments = [
      {
        'prefix':
            'La que suscribe, por este medio hace constar que el (la) estudiante ',
        'key': 'Nombre',
      },
      {'prefix': ' con número de control ', 'key': 'NumeroControl'},
      {'prefix': ' de la carrera de ', 'key': 'Carrera'},
      {
        'prefix': ', ha CUMPLIDO la actividad complementaria: ',
        'key': 'ActividadComplementaria',
      },
      {'prefix': ', con el nivel de desempeño ', 'key': 'Desempenio'},
      {'prefix': ', valor numérico de ', 'key': 'Valornumerico'},
      {'prefix': ', valor curricular de ', 'key': 'Creditos'},
      {
        'prefix': ' crédito(s), durante el período escolar: ',
        'key': 'PeriodoEscolar',
      },
      {'prefix': '.', 'key': null},
    ];

    // Función pura para formatear el valor de un campo
    String formatearValor(dynamic value) =>
        value != null
            ? '<b>${value.toString()}</b>'
            : '<b>[Valor no especificado]</b>';

    return segments
        .map((segment) {
          final prefix = segment['prefix'] as String;
          final key = segment['key'];

          return key != null && !_editando
              ? prefix + formatearValor(_constancia[key])
              : prefix;
        })
        .fold<String>('', (accumulated, segment) => accumulated + segment);
  }

  @override
  Widget build(BuildContext context) {
    // Muestra indicador de carga si los datos están cargando
    if (_cargando) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    // Conversión de medidas (milímetros a puntos para consistencia en diferentes dispositivos)
    const double mmToPoints = 2.83465;
    final anchoCarta =
        215.9 * mmToPoints; // Ancho estándar de hoja carta (215.9 mm)
    final altoCarta =
        225.0 * mmToPoints; // Alto ajustado (original sería 279.4 mm)

    return Scaffold(
      appBar: AppBar(
        title: Text('Constancia ${_constancia['noOficio']}'),
        actions: [
          // Botón para cancelar edición (sólo visible en modo edición)
          if (_editando)
            IconButton(
              icon: const Icon(Icons.close, color: Colors.red, size: 22),
              onPressed: _alternarEdicion,
            ),
          // Botón para guardar/editar (cambia icono según el modo)
          IconButton(
            icon: Icon(_editando ? Icons.save : Icons.edit, size: 22),
            onPressed: _editando ? _guardarConstancia : _alternarEdicion,
          ),
        ],
      ),
      body: Center(
        child: InteractiveViewer(
          // Permite hacer zoom y pan sobre el documento
          boundaryMargin: const EdgeInsets.all(10),
          minScale: 0.8,
          maxScale: 3.0,
          child: Container(
            width: anchoCarta,
            height: altoCarta,
            // Padding convertido de mm a puntos
            padding: const EdgeInsets.only(
              left: 15 * mmToPoints, // Margen izquierdo ~25mm
              right: 15 * mmToPoints, // Margen derecho ~20mm
              top: 15 * mmToPoints, // Margen superior ~15mm
              bottom: 10 * mmToPoints,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(
                color: Colors.grey,
                width: 0.5,
              ), // Borde gris claro
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 6,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Encabezado con logos institucionales
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (_logoIzquierdo != null)
                      Image.memory(
                        _logoIzquierdo!,
                        width: 65 * mmToPoints, // ~35mm de ancho
                        height: 12 * mmToPoints, // ~12mm de alto
                        fit: BoxFit.contain,
                      ),
                    if (_logoDerecho != null)
                      Image.memory(
                        _logoDerecho!,
                        width: 60 * mmToPoints, // ~35mm de ancho
                        height: 12 * mmToPoints, // ~12mm de alto
                        fit: BoxFit.contain,
                      ),
                  ],
                ),
                SizedBox(height: 20 * mmToPoints), // Espaciado ~5mm
                // Sección de fecha y número de oficio (alineado a la derecha)
                Align(
                  alignment: Alignment.centerRight,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      // Fecha (Chetumal, Quintana Roo + fecha editable)
                      IntrinsicWidth(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.baseline,
                              textBaseline: TextBaseline.alphabetic,
                              children: [
                                Text(
                                  'Chetumal, Quintana Roo,',
                                  style: TextStyle(fontSize: _fontSize),
                                ),
                                Transform.translate(
                                  offset: const Offset(0, 0.1),
                                  child: SizedBox(
                                    width: 59,
                                    child: Text(
                                      _constancia['Fecha'] ?? '[Fecha]',
                                      style: TextStyle(
                                        fontSize: _fontSize,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      // Número de oficio
                      Text(
                        'Oficio No. ${_constancia['noOficio']}',
                        style: TextStyle(fontSize: _fontSize),
                      ),
                      SizedBox(height: 2 * mmToPoints),
                      // Asunto
                      IntrinsicWidth(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Asunto: ',
                                  style: TextStyle(fontSize: _fontSize),
                                ),
                                Container(
                                  width: 147,
                                  child: Text(
                                    _constancia['Asunto'] ?? '[Asunto]',
                                    style: TextStyle(
                                      fontSize: _fontSize,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 6 * mmToPoints), // Espaciado ~6mm
                // Destinatario (M.A. + departamento editable)
                RichText(
                  text: TextSpan(
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: _fontSize,
                      height: 1.1,
                      color: Colors.black,
                    ),
                    children: [
                      const TextSpan(text: 'M.A. '),
                      WidgetSpan(
                        alignment: PlaceholderAlignment.baseline,
                        baseline: TextBaseline.alphabetic,
                        child: Transform.translate(
                          offset: const Offset(0, 0.1),
                          child: SizedBox(
                            width: 200,
                            child: _construirCampoEditable(
                              '',
                              _constancia['DEPARTAMENTO_DE_SERVICIOS_ESCOLARES'],
                              'departamentoServiciosEscolares',
                            ),
                          ),
                        ),
                      ),
                      const TextSpan(
                        text:
                            '\nJEFA(E) DEL DEPARTAMENTO DE SERVICIOS ESCOLARES,\nPRESENTE.',
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 6 * mmToPoints), // Espaciado ~6mm
                // Contenido principal (scrollable)
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        _buildContenidoConstancia(), // Contenido generado dinámicamente
                        SizedBox(height: 4 * mmToPoints), // Espaciado ~4mm
                        // Fecha de emisión (día, mes, año)
                        Text(
                          'Se extiende la presente en la ciudad de Chetumal, Quintana Roo, a los '
                          '${_constancia['Dia']} días del mes de ${_constancia['Mes']} del año ${_constancia['Anio']}.',
                          style: TextStyle(fontSize: _fontSize, height: 1.1),
                        ),
                        SizedBox(height: 10 * mmToPoints), // Espaciado ~10mm
                        // Sección de firmas
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Columna izquierda (ATENTAMENTE)
                            Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'ATENTAMENTE',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: _fontSize,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 1 * mmToPoints,
                                  ), // Espaciado ~1mm
                                  // Lema institucional
                                  Text(
                                    'Excelencia en Educación Tecnológica®\n'
                                    'Cultura, Ciencia y Tecnología para la Superación de México®',
                                    style: TextStyle(
                                      fontSize:
                                          _fontSize * 0.7, // Texto más pequeño
                                      height: 1,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 8 * mmToPoints,
                                  ), // Espaciado ~8mm
                                  // Firma coordinación
                                  _construirCampoEditable(
                                    'Coordinación',
                                    _constancia['COORDINACION_DE_ORIENTACION_EDUCATIVA'],
                                    'coordinacionOrientacionEducativa',
                                  ),
                                  Text(
                                    'COORDINACIÓN DE ORIENTACIÓN EDUCATIVA',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: _fontSize,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Columna derecha (Vo.Bo.)
                            Flexible(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Vo.Bo.',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: _fontSize,
                                    ),
                                  ),
                                  SizedBox(
                                    height: 16 * mmToPoints,
                                  ), // Espaciado ~8mm
                                  // Firma jefa de departamento
                                  _construirCampoEditable(
                                    '',
                                    _constancia['JEFA_DEL_DEPTO_DE_DESARROLLO_ACADEMICO'],
                                    'jefaDeptoDesarrolloAcademico',
                                  ),
                                  Text(
                                    'JEFA DEL DEPTO. DE DESARROLLO ACADÉMICO',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: _fontSize,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                // Pie de página con imagen/logotipo
                if (_imagenPiePagina != null)
                  Center(
                    child: Image.memory(
                      _imagenPiePagina!,
                      width: 150 * mmToPoints, // ~150mm de ancho
                      height: 20 * mmToPoints, // ~20mm de alto
                      fit: BoxFit.contain,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
      // Botón flotante para guardar (sólo en modo edición)
      floatingActionButton:
          _editando
              ? FloatingActionButton(
                onPressed: _guardarConstancia,
                mini: true, // Tamaño compacto
                child: const Icon(Icons.save, size: 20),
              )
              : null,
    );
  }
}
