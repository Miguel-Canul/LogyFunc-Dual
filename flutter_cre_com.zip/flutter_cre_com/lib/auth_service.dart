import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

// Servicio para manejar la autenticación y autorización en la aplicación
// Autor: Miguel Antonio Canul Gerardo
class AuthService {
  // Configuración de endpoints
  static const String _baseUrl = 'http://10.0.2.2:7288/api/ConstanciaDetall';

  // Almacenamiento seguro para tokens y datos sensibles
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  // Cliente HTTP para realizar peticiones
  final http.Client client;

  // Constructor q
  AuthService({required this.client});

  // Realiza el proceso de autenticación con el servidor
  Future<bool> login(String email, String password, bool rememberMe) async {
    try {
      debugPrint('=== REQUEST LOGIN ===');
      debugPrint('Endpoint: $_baseUrl/login');

      final response = await client.post(
        Uri.parse('$_baseUrl/login'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'email': email,
          'password': password,
          'rememberMe': rememberMe,
        }),
      );

      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        final token = responseData['token'];

        debugPrint('Token recibido: $token');

        // Almacenamiento seguro de credenciales
        await Future.wait([
          _storage.write(key: 'jwt_token', value: token),
          _storage.write(key: 'email', value: responseData['email']),
        ]);

        // Verificación de almacenamiento
        final storedToken = await _storage.read(key: 'jwt_token');
        debugPrint('Token almacenado: $storedToken');

        return true;
      } else {
        final errorData = jsonDecode(response.body);
        throw Exception(errorData['message'] ?? 'Login failed');
      }
    } catch (e) {
      debugPrint('Login error: $e');
      rethrow;
    }
  }

  // Obtiene el token JWT almacenado
  Future<String?> _getToken() async {
    return await _storage.read(key: 'jwt_token');
  }

  // Genera los headers de autorización para peticiones HTTP
  Future<Map<String, String>> _getAuthHeaders() async {
    final token = await _getToken();
    debugPrint('🔍 Token recuperado para headers: $token');
    return {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // Método de depuración para verificar el almacenamiento
  Future<void> debugStorage() async {
    debugPrint('=== DEBUG STORAGE ===');
    final token = await _storage.read(key: 'jwt_token');
    final email = await _storage.read(key: 'email');

    debugPrint('Token en storage: $token');
    debugPrint('Email en storage: $email');
  }

  // Obtiene las constancias del usuario autenticado
  Future<List<dynamic>> getConstancias() async {
    try {
      final headers = await _getAuthHeaders();

      final response = await client.get(Uri.parse(_baseUrl), headers: headers);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else if (response.statusCode == 401) {
        await logout();
        throw Exception('Sesión expirada, por favor inicie sesión nuevamente');
      } else {
        throw Exception('Error al obtener constancias: ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('Error en getConstancias: $e');
      rethrow;
    }
  }

  // Cierra la sesión eliminando todos los datos almacenados
  Future<void> logout() async {
    try {
      await _storage.deleteAll();
    } catch (e) {
      debugPrint('Logout error: $e');
      rethrow;
    }
  }

  // Verifica si existe una sesión activa
  Future<bool> isLoggedIn() async {
    try {
      final token = await _getToken();
      return token != null;
    } catch (e) {
      return false;
    }
  }

  // Obtiene el email del usuario almacenado
  Future<String?> getEmail() async {
    return await _storage.read(key: 'email');
  }
}
