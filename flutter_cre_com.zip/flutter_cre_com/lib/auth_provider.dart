import 'package:flutter/foundation.dart';
import 'auth_service.dart';
import 'service.dart';

/// Provider para manejar el estado de autenticación de la aplicación
///
/// Autor: Miguel Antonio Canul Gerardo
///
/// Contiene:
/// - Gestionar el login/logout de usuarios
/// - Mantener el estado de autenticación
/// - Manejar errores y estado de carga
/// - Proporcionar acceso a datos del usuario autenticado
class AuthProvider with ChangeNotifier {
  final AuthService _authService;
  final ApiService _apiService;

  // Estado interno
  bool _isLoading = false;
  String? _errorMessage;
  String? _currentEmail;

  /// Constructor que requiere:
  AuthProvider({
    required AuthService authService,
    required ApiService apiService,
  }) : _authService = authService,
       _apiService = apiService;

  // Getters públicos para el estado
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String? get currentEmail => _currentEmail;

  /// Inicializa el provider verificando la sesión existente
  Future<void> initialize() async {
    _currentEmail = await _authService.getEmail();
    notifyListeners();
  }

  /// Realiza el proceso de login
  Future<bool> login(String email, String password, bool rememberMe) async {
    try {
      _setLoading(true);
      _setError(null);

      final success = await _authService.login(email, password, rememberMe);
      if (success) {
        _currentEmail = email;
        notifyListeners();
        return true;
      }
      return false;
    } catch (e) {
      _setError(e.toString());
      rethrow;
    } finally {
      _setLoading(false);
    }
  }

  /// Cierra la sesión actual del usuario
  Future<void> logout() async {
    try {
      _setLoading(true);
      await _authService.logout();
      _currentEmail = null;
      notifyListeners();
    } catch (e) {
      _setError(e.toString());
      rethrow;
    } finally {
      _setLoading(false);
    }
  }

  /// Verifica si existe una sesión activa
  Future<bool> checkAuth() async {
    final isLogged = await _authService.isLoggedIn();
    if (!isLogged) {
      _currentEmail = null;
    } else {
      _currentEmail = await _authService.getEmail();
    }
    notifyListeners();
    return isLogged;
  }

  /// Obtiene las constancias del usuario autenticado
  Future<List<dynamic>> getConstancias() async {
    try {
      _setLoading(true);
      final constancias = await _apiService.getTodasConstanciasDetalladas();
      return constancias;
    } catch (e) {
      _setError(e.toString());

      // Cierra sesión si el error es de autenticación (401)
      if (e.toString().contains('401')) {
        await logout();
      }

      rethrow;
    } finally {
      _setLoading(false);
    }
  }

  /// Actualiza el estado de carga y notifica a los listeners
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  /// Actualiza el mensaje de error y notifica a los listeners
  void _setError(String? error) {
    _errorMessage = error;
    notifyListeners();
  }
}
